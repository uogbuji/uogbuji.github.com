#! /usr/bin/python

##################################################################################
#                                                                                #
# enbus08.py   Library used for parsing and managing information defined in RDF  #
# Copyright (C) 2004 Leonardo Maycotte                                           #
#                                                                                #
# This library is free software; you can redistribute it and/or                  #
# modify it under the terms of the GNU Library General Public                    #
# License as published by the Free Software Foundation; either                   #
# version 2 of the License, or (at your option) any later version.               #
#                                                                                #
# This library is distributed in the hope that it will be useful,                #
# but WITHOUT ANY WARRANTY; without even the implied warranty of                 #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU              #
# Library General Public License for more details.                               #
#                                                                                #
# You should have received a copy of the GNU Library General Public              #
# License along with this library; if not, write to the                          #
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,                   #
# Boston, MA  02111-1307, USA.                                                   #
#                                                                                # 
# contact email: lmaycotte@hotmail.com                                           #
#                                                                                #
##################################################################################

import lib
from Ft.Rdf import Util
from Ft.Rdf.Util import *

#schema = 'corporation'
schema='school'

file = schema +'.rdf'
rdfs = schema +'.rdfs'

path ='/var/www/html/umbrella/' +file
path2 ='/var/www/html/umbrella/' +rdfs

NSS = {'rdf': "http://www.w3.org/1999/02/22-rdf-syntax-ns#" ,
         'dc': "http://purl.org/dc/elements/1.1/",
         'sy': "http://purl.org/rss/1.0/modules/syndication/",
         'rss': "http://purl.org/rss/1.0/",
         'vsort': "http://rdfinference.org/versa/0/2/sort/",
       'a':"http://protege.stanford.edu/system#",
       'rdfs':"http://www.w3.org/TR/1999/PR-rdf-schema-19990303#",
       'empresa':"http://10.17.134.162/umbrella/empresa#",
       'escolar':"http://10.17.134.162/umbrella/escolar#",
       'corporation':"http://10.17.134.162/umbrella/corporation#",
       'school':"http://10.17.134.162/umbrella/school#"
       }

m, driver = DeserializeFromUri(path)
d, driver = DeserializeFromUri(path2)

def getPropertys():
  resul = d.complete(None, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#Property')
  lista = []
  select = []
  for stmt in resul:
    lista.append(stmt.subject)
  for x in range(len(lista)):
    fi = lista[x].find('#')
    select.append(lista[x][fi+1:])
  return select

def encode(lista):
  resul = []
  for x in range(len(lista)):
    resul.append(lista[x].encode('utf-8'))
  return resul

#obtiene los ID de un tipo de dato (gets the ID's of one type of data)
def getID(dato,tipo):
  query = '("' +dato +'" <-' +schema +':' +tipo +' - *) - ' +schema +':ID -> *'
  resul = Util.VersaQuery(query, m, nsMap=NSS)
  resul = encode(resul)
  if type(resul).__name__!='list':
    return [resul]
  else:
    return resul

#a partir del ID obtiene informacion deseada (from the ID it gets the desired information)
def busqa(ID,bus):
  query = '("' +ID +'" <- ' +schema +':ID - *) - ' +schema +':' +bus +' -> *'
  resul = Util.VersaQuery(query, m, nsMap=NSS)
  resul = encode(resul)
  return resul

#elimina elementos repetidos de una lista (eliminates repeated elements from a list)
def elimina(lista):
  ini= 0
  lista.sort()
  while ini < len(lista)-1:
    if lista[ini] == lista[ini+1]:
      del lista[ini+1]
    else:
      ini= ini+1
  return lista

#obtiene elementos repetidos de una lista (gets repeated elements from a list)
def repet(lista):
  ini= 0
  resul = []
  lista.sort()
  while ini < len(lista)-1:
    if lista[ini] == lista[ini+1]:
      del lista[ini+1]
      if not resul or resul[-1:][0] != lista[ini]:
        resul.append(lista[ini])
    else:
      ini= ini+1
  return resul

#genera una lista a partir de una lista de listas (generates a list from a list of lists)
def genLis(listas):
  resul = []
  for x in listas:
    for y in x:
      resul.append(y)
  return resul

#obtiene el id del match nombre, apellido paterno y apellido materno (gets the ID of the match: Name or last names)
def tresDat(ids,lista):
  ie = ''
  for i in ids:
    c = lista.count(i)
    if c==3:
      ie = i
  return [ie]

#regresa una tupla con listas de ids y resultados (returns a tuple with lists of ID's and results)
def nombreComp(nombre, Ap, Am, dato,iden):
  ids = []
  lis = []
  resul = []
  if iden == None:
    if nombre != None:
      idNom = getID(nombre, 'Name')
      ids.append(idNom)
      lis.append(idNom)
    if Ap != None:
      idAp = getID(Ap, 'Middle_name')
      ids.append(idAp)
      lis.append(idAp)
    if Am != None:
      idAm = getID(Am, 'Last_name')
      ids.append(idAm)
      lis.append(idAm)
    ids = genLis(ids)
    lis = genLis(lis)
    if nombre!=None and Ap!=None and Am!=None:
      ids = repet(ids)
      ids = tresDat(ids,lis)
      resul = busqa(ids[0], dato)
      resul = [resul]
    elif nombre!=None and Ap!=None and Am==None:
      resul,ids =  nomDos(ids,dato,2)
    elif nombre!=None and Am!=None and Ap==None:
      resul,ids =  nomDos(ids,dato,2)
    elif Ap!=None and Am!=None and nombre==None:
      resul,ids = nomDos(ids,dato,2)
    elif nombre!=None and Ap==None and Am==None:
      resul,ids = nomDos(ids,dato,1) 
    elif Ap!=None and nombre==None and Am==None:
      resul,ids = nomDos(ids,dato,1)
    elif Am!=None and nombre==None and Ap==None:
      resul,ids = nomDos(ids,dato,1)
  else:
    ids = iden
    resul,ids = nomDos(ids,dato,1)
  resul = eliRepe(resul)
  return ids,resul

#elimina resultados repetidos (eliminates repeated results)
def eliRepe(resul):
  for x in range(len(resul)):
    resul[x]=elimina(resul[x])
  return resul
  
def nomDos(ids,dato,set):
  resul = []
  if set==2:
    ids = repet(ids)
  for x in ids:
    resul.append(busqa(x,dato))
  return resul,ids

def runBus(nombre,Apaterno,Amaterno,dato,iden):
  resul = nombreComp(nombre,Apaterno,Amaterno,dato,iden)
  nomtot = []
  for id in resul[0]:
    nombre = []
    nom = busqa(id,'Name')
    Apaterno = busqa(id,'Middle_name')
    Amaterno = busqa(id,'Last_name')
    if nom:
      nombre.append(nom[0])
    else:
      nom = None
    if Apaterno:
      nombre.append(Apaterno[0])
    if Amaterno:
      nombre.append(Amaterno[0])
    nomtot.append(nombre)

  noms = []
  for s in nomtot:
    str = ''
    for n in range(len(s)):
      str = str +' '+s[n]
    noms.append(str)

  datos= resul[1]

  Tabla = lib.Table()
  Tabla.setClase('TablaMonitor')
  encabezado = lib.Tablerow()
  encabezado.setClase('EncabezadoTablaListado')

  titulo = ['Name', dato]
  for y in titulo:
    celda = lib.Tabledata()
    celda.setData(y)
    celda.setTipo('t')
    encabezado.agregaCelda(celda)
  Tabla.agregaRenglon(encabezado)

  for x in range(len(noms)):
    renglon = lib.Tablerow()
    renglon.setClase('CeldaServicio')
    celda = lib.Tabledata()
    celda.setTipo('t')
    celda.setData(noms[x])
    renglon.agregaCelda(celda)
    celda = lib.Tabledata()
    celda.setTipo('t')
    str = ''
    for z in datos[x]:
      str = str +z +'.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;'
    if str == '':
      str = 'No data available'
    celda.setData(str)
    renglon.agregaCelda(celda)
    Tabla.agregaRenglon(renglon)

  if noms:
    Tabla.imprimeTabla()
  else:
    print '<h3>No data available</h3>'

#! /usr/bin/python

################################################################################
#                                                                              #
# enempl.py  Parses an RDF schema file                                         #
# Copyright (C) 2004 Leonardo Maycotte                                         #
#                                                                              #
# This program is free software; you can redistribute it and/or                #
# modify it under the terms of the GNU General Public License                  #
# as published by the Free Software Foundation; either version 2               #
# of the License, or (at your option) any later version.                       #
#                                                                              #
# This program is distributed in the hope that it will be useful,              #
# but WITHOUT ANY WARRANTY; without even the implied warranty of               #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #
# GNU General Public License for more details.                                 #
#                                                                              #
# You should have received a copy of the GNU General Public License            #
# along with this program; if not, write to the Free Software                  #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  #
#                                                                              #
# contact email: lmaycotte@hotmail.com                                         #
#                                                                              #
################################################################################

import lib, cgi, string, time, enbus08

lib.iniHtml()
print '''<script type="text/javascript">
<!-- hide

  function valida(forma) { // Checa si la forma es valida
    if ((forma.dato.options[0].selected==true) || (forma.dato.options[1].selected== true)) {
      alert("Please select one or more fields and deselect non-fields");
      return false;
    }
  }
// -->
</script>'''
print '''<h2>Search by Name</h2>'''
lib.iniHtml2('Umbrella Information Technologies Search')
lib.br(1)

print '<h3>Fill in one, two or the three fields below</h3>'

lib.br(1)
lib.abreCentrar()

print '<form method="POST" action="enemp.py" onSubmit="return valida(this);" target=_self>'

Tabla = lib.Table()
Tabla.setClase('TablaConsultas')

renglon = lib.Tablerow()
celda = lib.Tabledata()
celda.setData('First name:')
celda.setTipo('t')
renglon.agregaCelda(celda)
input = lib.Input()
input.setType('text')
input.setName('nombre')
input.setSize('15')
celda = lib.Tabledata()
celda.setData(input)
renglon.agregaCelda(celda)
Tabla.agregaRenglon(renglon)

renglon = lib.Tablerow()
celda = lib.Tabledata()
celda.setData('Middle name:')
celda.setTipo('t')
renglon.agregaCelda(celda)
input = lib.Input()
input.setType('text')
input.setName('Apaterno')
input.setSize('15')
celda = lib.Tabledata()
celda.setData(input)
renglon.agregaCelda(celda)
Tabla.agregaRenglon(renglon)

renglon = lib.Tablerow()
celda = lib.Tabledata()
celda.setData('Last name:')
celda.setTipo('t')
renglon.agregaCelda(celda)
input = lib.Input()
input.setType('text')
input.setName('Amaterno')
input.setSize('15')
celda = lib.Tabledata()
celda.setData(input)
renglon.agregaCelda(celda)
Tabla.agregaRenglon(renglon)

renglon = lib.Tablerow()
celda = lib.Tabledata()
celda.setData('ID:')
celda.setTipo('t')
renglon.agregaCelda(celda)
input = lib.Input()
input.setType('text')
input.setName('iden')
input.setSize('15')
celda = lib.Tabledata()
celda.setData(input)
renglon.agregaCelda(celda)
Tabla.agregaRenglon(renglon)

renglon = lib.Tablerow()
celda = lib.Tabledata()
celda.setData('Data available:')
celda.setTipo('t')
renglon.agregaCelda(celda)

datos = lib.Select()
datos.setName('dato')
datos.setMultiple('multiple')
opcion = lib.Option()
datos.agregaOpcion(opcion)
datos.options[0].setElement('Select one or more')
datos.options[0].setSelected('selected')
opcion = lib.Option()
datos.agregaOpcion(opcion)
datos.options[1].setElement('______________')

lisOp = enbus08.getPropertys()
#lisOp = ['telefono', 'email', 'Responsabilidades', 'Hijos', 'Departamentos']

for i in range(len(lisOp)):
  opcion = lib.Option()
  opcion.value = opcion.element = lisOp[i]
  datos.agregaOpcion(opcion)

celda = lib.Tabledata()
celda.setData(datos)
renglon.agregaCelda(celda)
Tabla.agregaRenglon(renglon)

Tabla.imprimeTabla()

lib.br(2)
lib.botonRegresar()
lib.botonLimpiard('')
lib.botonAceptard('')
lib.cerrarForma()
lib.htmlEnd2()

#! /usr/bin/python

##################################################################################
#                                                                                #
# lib.py   Library used for generating dynamic HTML objects                      #
# Copyright (C) 2004 Leonardo Maycotte                                           #
#                                                                                #
# This library is free software; you can redistribute it and/or                  #
# modify it under the terms of the GNU Library General Public                    #
# License as published by the Free Software Foundation; either                   #
# version 2 of the License, or (at your option) any later version.               #
#                                                                                #
# This library is distributed in the hope that it will be useful,                #
# but WITHOUT ANY WARRANTY; without even the implied warranty of                 #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU              #
# Library General Public License for more details.                               #
#                                                                                #
# You should have received a copy of the GNU Library General Public              #
# License along with this library; if not, write to the                          #
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,                   #
# Boston, MA  02111-1307, USA.                                                   #
#                                                                                # 
# contact email: lmaycotte@hotmail.com                                           #
#                                                                                #
##################################################################################

import time, string, os, posixfile

def iniHtml():
   print "Content-type: text/html"
   print ""
   print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">'
   print '<!-- Part of the umbrella project -->'
   print ''' 
         <html>
         <head>
         <LINK REL="stylesheet" HREF="http://localhost/temp/template.css" TYPE="text/css">
         <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
         '''

def iniHtml2(title):
   if title == '':
      title = 'Untitled Document'
   print '<title>',title,'</title>'
   print '</head>'
   print '<body>'

def htmlEnd():
   print '</body>'
   print '</html>'

def htmlEnd2():
   br(2)
   hr()
   print '</body>'
   print '</html>'

def separaBoton():
   print '<font size=6px>|</font>'

def abreForma():
  print '<center><form action="">'

def cerrarForma():
  print "</form></center>"

def abreCentrar():
  print '<center>'

def cerrarCentrar():
  print '</center>'

def valorDelCampo(form, key):
   if form.has_key(key):
     pp=form[key]
     if type(pp).__name__ == 'list':
       res=[]
       for i in range(len(pp)):
         res.append(pp[i].value)
       return res
     else:
       return [pp.value]
   else:
     return []

def makeLista(tupla):
  list=[]
  if tupla:
    for y in range(len(tupla)):
      list.append(tupla[y])
  return list

def listaDeTuplas(lista):
  list=[]
  for w in range(len(lista)):
    list.append(makeLista(lista[w]))
  return list

def hr():
   print '<hr>'

def br(n):
   for i in range(n):
      print '<br>'

def botonLimpiard(d):
  boton=Button()
  boton.setType("reset")
  boton.setName("Limpiar")
  boton.setClase("boton")
  boton.setValue("Limpiar")
  boton.setText("Clear")
  if d:
    boton.setDisabled('1')
  boton.imprimeBoton()

def botonRegresar():
  boton=Button()
  boton.setName("Regresar")
  boton.setText("&#060;&#060;Back")
  boton.setClase("Boton")
  boton.setType("button")
  boton.setOnclick("history.go(-1)")
  boton.imprimeBoton()

def botonAceptard(d):
  boton=Button()
  boton.setType("submit")
  boton.setName("Aceptar")
  boton.setClase("boton")
  boton.setValue("Aceptar")
  boton.setText("Submit")
  if d:
    boton.setDisabled('1')
  boton.imprimeBoton()

#clases tabledata,tablerow y table
class Tabledata:
    align=valign=clase=data=tipo=width=colspan=''
    def setAlign(self,val):
        self.align = val
    def setValign(self,val):
        self.valign = val
    def setClase(self,val):
        self.clase = val
    def setData(self,val):
        self.data = val
    def setColspan(self,val):
        self.colspan = val
    def setTipo(self,val):
        self.tipo = val
    def setWidth(self,val):
        self.width = val        
    def imprimeData(self):
        if self.tipo=='t':
            print unicode(self.data,'utf-8').encode('iso-8859-1')
        elif self.data.tipo=='s':
            self.data.imprimeSelect()
        elif self.data.tipo=='b':
            self.data.imprimeBoton()
        elif self.data.tipo=='l':
            self.data.imprimeLink()
        elif self.data.tipo=='i':
            self.data.imprimeInput()
        elif self.data.tipo=='a':
            self.data.imprimeTextarea()
        elif self.data.tipo=='T':
            self.data.imprimeTabla()
     
        
class Tablerow:
    celda = ''
    align=clase=valign=''
    def setAlign(self,val):
        self.align = val
    def setValign(self,val):
        self.valign = val
    def setClase(self,val):
        self.clase = val
    def agregaCelda(self,val):
        if not self.celda:
            self.celda=[]
        self.celda.append(val)

class Table:
    tipo='T'
    renglon = ''
    width=border=cellpadding=cellspacing=clase=''
    def setWidth(self,val):
        self.width = val
    def setBorder(self,val):
        self.border = val
    def setCellpadding(self,val):
        self.cellpadding = val
    def setCellspacing(self,val):
        self.cellspacing = val
    def setClase(self,val):
        self.clase = val
    def agregaRenglon(self,val):
        if not self.renglon:
            self.renglon=[]
        self.renglon.append(val)
        
    def imprimeTabla(self):
        atrb=''
        if self.width:
            atrb=atrb+' width="%s"' %self.width
        if self.border:
            atrb=atrb+' border="%s"' %self.border
        if self.cellpadding:
            atrb=atrb+' cellpadding="%s"' %self.cellpadding
        if self.cellspacing:
            atrb=atrb+' cellspacing="%s"' %self.cellspacing
        if self.clase:
            atrb=atrb+' class="%s"' %self.clase
        print '<Table %s>' %atrb
        for renglon in self.renglon:
            atrb=''
            if renglon.align:
                atrb=atrb+' align="%s"' %renglon.align
            if renglon.valign:
                atrb=atrb+' valign="%s"' %renglon.valign
            if renglon.clase:
                atrb=atrb+' class="%s"' %renglon.clase
            print '   <TR %s>' %atrb
            for celda in renglon.celda:
                atrb=''
                if celda.align:
                    atrb=atrb+' align="%s"' %celda.align
                if celda.valign:
                    atrb=atrb+' valign="%s"' %celda.valign
                if celda.clase:
                    atrb=atrb+' class="%s"' %celda.clase
                if celda.width:
                    atrb=atrb+' width="%s"' %celda.width
                if celda.colspan:
                    atrb=atrb+' colspan="%s"' %celda.colspan
                print '      <TD %s>' %atrb
                print '         ',
                celda.imprimeData()
        print '</Table>'
        
class Textarea:
    name=rows=value=cols=disabled=clase=text=''
    tipo='a'
    def setName(self,val):
      self.name = val
    def setRows(self,val):
      self.rows = val
    def setClase(self,val):
      self.clase = val
    def setCols(self,val):
      self.cols = val
    def setDisabled(self,val):
      self.disabled = val
    def setText(self,val):
      self.text = val
    def imprimeTextarea(self):
      atrb=''
      if self.name:
          atrb=atrb+' name="%s"' %self.name
      if self.rows:
          atrb=atrb+' rows="%s"' %self.rows
      if self.cols:
          atrb=atrb+' cols="%s"' %self.cols
      if self.clase:
          atrb=atrb+' clase="%s"' %self.clase
      if self.disabled:
          atrb=atrb+' disabled'
      print '<Textarea%s>%s</Textarea>' %(atrb, self.text)

      
        
class Input:
    type=name=value=size=onclick=clase=onfocus=checked=disabled=''
    tipo='i'
    def setType(self,val):
      self.type = val
    def setName(self,val):
      self.name = val
    def setValue(self,val):
      self.value = val
    def setClase(self,val):
      self.clase = val
    def setChecked(self,val):
      self.checked = val
    def setSize(self,val):
      self.size = val
    def setDisabled(self,val):
      self.disabled = val
    def setOnclick(self,val):
      self.onclick = val
    def setOnfocus(self,val):
      self.onfocus = val
    def imprimeInput(self):
      atrb=''
      if self.type:
          atrb=atrb+' type="%s"' %self.type
      if self.clase:
          atrb=atrb+' class="%s"' %self.clase
      if self.name:
          atrb=atrb+' name="%s"' %self.name
      if self.value:
          atrb=atrb+' value="%s"' %self.value
      if self.checked:
          atrb=atrb+' checked'      
      if self.size:
          atrb=atrb+' size="%s"' %self.size
      if self.onclick:
          atrb=atrb+' onclick="%s"' %self.onclick
      if self.disabled:
          atrb=atrb+' disabled'
      if self.onfocus:
          atrb=atrb+' onFocus="%s"' %self.onfocus
      print '<Input%s>' %(atrb)
              

class Link:
    href=clase=target=text=''
    tipo='l'
    def setHref(self,val):
        self.href = val
    def setClase(self,val):
        self.clase = val
    def setTarget(self,val):
        self.target = val
    def setText(self,val):
        self.text = val
    def imprimeLink(self):
        atrb=''
        if self.href:
            atrb=atrb+' href="%s"' %self.href
        if self.clase:
            atrb=atrb+' class="%s"' %self.clase
        if self.target:
            atrb=atrb+' target="%s"' %self.target
        print '<A%s>%s</A>' %(atrb,self.text)
        
    

class Button:
    value=type=name=disabled=onclick=text=imgsrc=clase=''
    tipo='b'
    def setValue(self,val):
        self.value = val    
    def setType(self,val):
        self.type = val
    def setName(self,val):
        self.name = val
    def setDisabled(self,val):
        self.disabled = val
    def setOnclick(self,val):
        self.onclick = val
    def setText(self,val):
        self.text = val
    def setClase(self,val):
        self.clase = val
    def setImgsrc(self,val):
        self.imgsrc = val
    def imprimeBoton(self):
        atrb=''
        if self.clase:
            atrb=atrb+' class="%s"' %self.clase 
        if self.value:
            atrb=atrb+' value="%s"' %self.value
        if self.disabled:
            atrb=atrb+' disabled' 
        if self.type:
            atrb=atrb+' type="%s"' %self.type
        if self.name:
            atrb=atrb+' name="%s"' %self.name
        if self.onclick:
            atrb=atrb+' onclick="%s"' %self.onclick
        print '<Button%s>' %atrb,
        print self.text,
        if self.imgsrc:
            print '<Img src="%s">' %self.imgsrc,
        print '</Button>'
   
        
#Select options+

class Option:
    value=''
    selected=element=''
    def setValue(self,val):
        self.value=val
    def setSelected(self,val):
        self.selected=val
    def setElement(self,val):
        self.element=val            

class Select:
    tipo='s'
    name=size=multiple=options=disabled=onchange=''
    def setName(self,val):
        self.name = val
    def setSize(self,val):
        self.size = val
    def setMultiple(self,val):
        self.multiple = val
    def setClass(self,val):
        self.clase = val
    def setOnchange(self,val):
        self.onchange = val
    def setDisabled(self,val):
        self.disabled = val
    def agregaOpcion(self,val):
        if not self.options:
           self.options = []
        self.options.append(val)
    def imprimeSelect(self):
        atrb=''
        if self.name:
            atrb=atrb+' name="%s"' %self.name
        if self.size:
            atrb=atrb+' size="%s"' %self.size
        if self.multiple:
            atrb=atrb+' multiple'
        if self.disabled:
            atrb=atrb+' disabled'       
        if self.onchange:
            atrb=atrb+' onchange="%s"' %self.onchange
        print '<Select%s>' %atrb
        #if not self.options:
        #    print '    <Option> --------'
        #else:
        for opcion in self.options:
            atrb=''
            if opcion.value:
                atrb=atrb+' value="%s"' %opcion.value
            if opcion.selected:
                atrb=atrb+' selected'
            print '    <Option %s>' %atrb,opcion.element
        print '</Select>'

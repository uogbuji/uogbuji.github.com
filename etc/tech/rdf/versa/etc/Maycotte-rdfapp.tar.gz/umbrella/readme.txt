 Umbrella Search Engine: Software for parsing and managing data in RDF files with python.

 Copyright (C) 2004 Leonardo Maycotte                                         
                                                                              
 This program is free software; you can redistribute it and/or                
 modify it under the terms of the GNU General Public License                  
 as published by the Free Software Foundation; either version 2               
 of the License, or (at your option) any later version.                       
                                                                              
 This program is distributed in the hope that it will be useful,              
 but WITHOUT ANY WARRANTY; without even the implied warranty of               
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                
 GNU General Public License for more details.                                 
                                                                              
 You should have received a copy of the GNU General Public License            
 along with this program; if not, write to the Free Software                  
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
                                                                              
 contact email: lmaycotte@hotmail.com                                         
                                                                              

This software is a web application that runs as python CGI's. It
starts with one html file (umbrella.html) then runs a python cgi
(enempl.py) that parses an rdf schema file and displays to the user
search options in HTML. Once the search options are specified by the user
it runs the enemp.py that parses an rdf file in search for data
selected by the user and displays the search results in HTML. 

To get a better idea of how this software can be used read the art.pdf
file.


Package files:

umbrella.html  ---------> start file that calls enempl.py python cgi.
template.css   ---------> cascade style sheet for html rendering. 
index_08.jpg   ---------> application logo. 
lib.py         ---------> author library for creating dinamic html objects in python.
enbus08.py     ---------> application search engine with other functions. 
enempl.py      ---------> python cgi that parses rdf schema file.
enemp.py       ---------> python cgi that parses rdf file. 

Example files:

corporation.pprj   -----> Used to be opened as a Protege project
corporation.rdfs   -----> Example rdfs file
corporation.rdf    -----> Example rdf file
school.pprj        -----> Another example
school.rdfs          
school.rdf

Python libraries used:

cgi, string, time, os


System requirements:

HTTP Server.  ----> More information in: http://www.apache.org/
Python.       ----> More information in: http://www.python.org/
4Suite        ----> http://4suite.org/index.xhtml


Optional system requirements: 

Protege      ----> http://protege.stanford.edu/

This system uses RDFS and RDF files with the structure seen in the
example files. You can create this files with Protege and its RDF
Plugin or another editor. 



INSTALL Instructions

1) Put the umbrella.html file in your html server file directory.
   
   For example:  /var/www/html/

2) Put the index_08.jpg in /var/www/html/images/ (create directory if it
   doesn't exists)

3) Put the template.css in /var/www/html/temp/ (create directory if it
   doesn't exists)

4) Put enbus08.py, lib.py, enempl.py, enemp.py in /var/www/cgi-bin/

5) Put the example files in /var/www/html/umbrella (create the
   umbrella directory).

6) Open your web browser and start the application!!

   For example: http://localhost/umbrella.html



Important Points

1)The variable schema in enbus08.py determines the files to be
  parsed. If your rdf and rdfs files have different names, read
  carefully the code in enbus08.py. Also if you plan to change file
  locations.  

1b) To change examples from corporation to school just change the
schema variable in enbus08.py

1c) File locations are given in the path /var/www/html/umbrella if
your server manages another path change the code in enbus08.py

2)Don't forget to add namespaces of your files to the NSS variable in enbus08.py.

3) You can change First name, Last name, or Middle name to other type
   of data. Read the code carefully to do it. 

#! /usr/bin/python

################################################################################
#                                                                              #
# enemp.py  Parses an RDF file                                                 #
# Copyright (C) 2004 Leonardo Maycotte                                         #
#                                                                              #
# This program is free software; you can redistribute it and/or                #
# modify it under the terms of the GNU General Public License                  #
# as published by the Free Software Foundation; either version 2               #
# of the License, or (at your option) any later version.                       #
#                                                                              #
# This program is distributed in the hope that it will be useful,              #
# but WITHOUT ANY WARRANTY; without even the implied warranty of               #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #
# GNU General Public License for more details.                                 #
#                                                                              #
# You should have received a copy of the GNU General Public License            #
# along with this program; if not, write to the Free Software                  #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  #
#                                                                              #
# contact email: lmaycotte@hotmail.com                                         #
#                                                                              #
################################################################################

from Ft.Rdf import Util
from Ft.Rdf.Util import *
import lib, cgi, string, time, enbus08
form = cgi.FieldStorage()

nombre     = lib.valorDelCampo(form, 'nombre')
Apaterno   = lib.valorDelCampo(form, "Apaterno")
Amaterno   = lib.valorDelCampo(form, "Amaterno")
dato       = lib.valorDelCampo(form, "dato")
iden       = lib.valorDelCampo(form, "iden")

lib.iniHtml()
lib.iniHtml2('Umbrella Information Technologies Search')

print '''
<h2>Search by Name</h2>
<h1>Search Results</h1>
<hr>
<br>
<br>
<center>'''

if not nombre:
  nombre = None
else:
  nombre = nombre[0].capitalize()
if not Apaterno:
  Apaterno = None
else:
  Apaterno = Apaterno[0].capitalize()
if not Amaterno:
  Amaterno = None
else:
  Amaterno = Amaterno[0].capitalize()
if not dato:
  dato = None
if not iden:
  iden = None

for dat in dato:
  enbus08.runBus(nombre,Apaterno,Amaterno,dat,iden)
  lib.br(1)
  lib.hr()
  lib.br(1)

lib.botonRegresar()
lib.cerrarCentrar()
lib.br(2)
lib.htmlEnd()

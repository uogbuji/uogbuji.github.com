#Basic tests from stron 1.5 spec ( http://xml.ascc.net/resource/schematron/Schematron2000.html )
import sys
import os, popen2
import cStringIO
import unittest
import tempfile
from amara import scimitar
from Ft.Xml import InputSource
from Ft.Lib import Uri

ENCODING = 'utf-8'


STRON1 = '''\
<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://www.ascc.net/xml/schematron" version="ISO">
 <sch:title>Example Schematron Schema</sch:title>
 <sch:pattern>
   <sch:rule context="dog">
    <sch:assert test="count(ear) = 2"
    >A 'dog' element should contain two 'ear' elements.</sch:assert>
    <sch:report test="bone"
    >This dog has a bone.</sch:report>
   </sch:rule>
  </sch:pattern>
</sch:schema>
'''

STRON2 = '''\
<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://www.ascc.net/xml/schematron" version="ISO">
 <sch:title>Example Schematron Schema</sch:title>
 <sch:pattern>
   <sch:rule context="dog">
    <sch:assert test="count(ear) = 2"
    >A '<sch:name/>' element should contain two 'ear' elements. Test value: <sch:value-of select="10*10"/></sch:assert>
    <sch:report test="bone"
    >This dog has a bone.</sch:report>
   </sch:rule>
  </sch:pattern>
</sch:schema>
'''

STRON3 = '''\
<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://www.ascc.net/xml/schematron" version="ISO">
 <sch:title>Example Schematron Schema</sch:title>
 <sch:pattern>
  <sch:rule context="dog" >
   <sch:assert test="nose | @exceptional='true'" diagnostics="d1 d2"
   >A dog should have a nose.</sch:assert>
  </sch:rule>
 </sch:pattern>

 <sch:diagnostics>
 <sch:diagnostic id="d1"
 >Your dog <sch:value-of select="@petname" /> has no nose. 
 How does he smell? Terrible. Give him a nose element,
 putting it after the <sch:name path="child::*[2]"/> element.
 </sch:diagnostic>
 <sch:diagnostic id="d2"
 >Animals such as <sch:name/> usually come with a full complement
 of legs, ears and noses, etc. However, exceptions are possible.
 If your dog is exceptional, provide an attribute
 <sch:emph>exceptional='true'</sch:emph>
 </sch:diagnostic>
</sch:diagnostics>
</sch:schema>
'''

STRON4 = '''\
<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://www.ascc.net/xml/schematron" version="ISO">
 <sch:title>Example with problem patterns</sch:title>
 <sch:pattern>
 </sch:pattern>
 <sch:pattern>
   <sch:rule>
    <sch:assert test="count(ear) = 2"
    >A 'dog' element should contain two 'ear' elements.</sch:assert>
   </sch:rule>
 </sch:pattern>
</sch:schema>
'''

INSTANCE1 = u'<dog><ear/><ear/></dog>'.encode(ENCODING)

INSTANCE2 = u'''\
<dog><ear/></dog>'''.encode(ENCODING)

INSTANCE3 = u'''\
<dog><ear/><bone/><ear/></dog>'''.encode(ENCODING)

INSTANCE4 = u'''\
<dog><ear/><bone/></dog>'''.encode(ENCODING)


def run_stron(stron_xml, candidate_xml, isrc_factory):
    stron_isrc = isrc_factory.fromString(stron_xml, 'urn:dummy')
    candidate_isrc = isrc_factory.fromString(candidate_xml, 'urn:dummy')
    validator_fname = tempfile.mkstemp('.py')[1]
    validator_file = open(validator_fname, 'w')
    scimitar.run(stron_isrc, validator_file, 1)
    validator_file.close()
    #(cstdin, cstdout) = os.popen4('/usr/bin/python ' + validator_fname + ' -')
    #cstdin.write(INSTANCE1)
    #result = cstdout.read()
    TEST = 1
    env = {'TEST': 1}
    execfile(validator_fname, env)
    validate = env['validate']
    #xmlf = cStringIO.StringIO(candidate_xml)
    result = cStringIO.StringIO()
    validate(candidate_isrc, result)
    os.unlink(validator_fname)
    try:
        os.unlink(validator_fname + 'c')
    except OSError:
        pass
    return result.getvalue()


def normalize_text(text):
    #normalize text, a bit slow for large files with much non-ws
    return reduce(lambda a, b: (a and a[-1].isspace() and b.isspace()) and a or a+b, text, '')


class TestBasics(unittest.TestCase):
    def setUp(self):
        self.isrc_factory = InputSource.DefaultFactory
        return

    def testStron1(self):
        output = run_stron(STRON1, INSTANCE1, self.isrc_factory)
        #print output
        #normalize text, a bit slow for large files with much non-ws
        output = normalize_text(output)
        #print output

        expected = '<?xml version="1.0" encoding="UTF-8"?>\nProcessing schema: Example Schematron Schema\nProcessing pattern: [unnamed]\n'
        self.assertEqual(output, expected)
        #self.assertRaises(AttributeError, binding.xbel.folder.)
        return

    def testStron2(self):
        output = run_stron(STRON1, INSTANCE3, self.isrc_factory)
        #print output
        #normalize text, a bit slow for large files with much non-ws
        output = normalize_text(output)
        #print output

        expected = '<?xml version="1.0" encoding="UTF-8"?>\nProcessing schema: Example Schematron Schema\nProcessing pattern: [unnamed]\nReport:\nThis dog has a bone.\n'
        self.assertEqual(output, expected)
        #self.assertRaises(AttributeError, binding.xbel.folder.)
        return

    def testStron3(self):
        output = run_stron(STRON1, INSTANCE2, self.isrc_factory)
        output = normalize_text(output)

        expected = '<?xml version="1.0" encoding="UTF-8"?>\nProcessing schema: Example Schematron Schema\nProcessing pattern: [unnamed]\nAssertion failure:\nA \'dog\' element should contain two \'ear\' elements.\n'
        self.assertEqual(output, expected)
        #self.assertRaises(AttributeError, binding.xbel.folder.)
        return

    def testStron4(self):
        output = run_stron(STRON3, INSTANCE1, self.isrc_factory)
        #print output
        #normalize text, a bit slow for large files with much non-ws
        output = normalize_text(output)
        #print output

        expected = '<?xml version="1.0" encoding="UTF-8"?>\nProcessing schema: Example Schematron Schema\nProcessing pattern: [unnamed]\nAssertion failure:\nA dog should have a nose.\nDiagnostic message:\nYour dog has no nose. How does he smell? Terrible. Give him a nose element,\nputting it after the ear element.\nDiagnostic message:\nAnimals such as dog usually come with a full complement\nof legs, ears and noses, etc. However, exceptions are possible.\nIf your dog is exceptional, provide an attribute\n<emph>exceptional=\'true\'</emph>\n'
        self.assertEqual(output, expected)
        #self.assertRaises(AttributeError, binding.xbel.folder.)
        return

    def testStron5(self):
        output = run_stron(STRON3, INSTANCE2, self.isrc_factory)
        #print output
        #normalize text, a bit slow for large files with much non-ws
        output = normalize_text(output)
        #print output

        expected = '<?xml version="1.0" encoding="UTF-8"?>\nProcessing schema: Example Schematron Schema\nProcessing pattern: [unnamed]\nAssertion failure:\nA dog should have a nose.\nDiagnostic message:\nYour dog has no nose. How does he smell? Terrible. Give him a nose element,\nputting it after the element.\nDiagnostic message:\nAnimals such as dog usually come with a full complement\nof legs, ears and noses, etc. However, exceptions are possible.\nIf your dog is exceptional, provide an attribute\n<emph>exceptional=\'true\'</emph>\n'
        self.assertEqual(output, expected)
        #self.assertRaises(AttributeError, binding.xbel.folder.)
        return

    def testStron6(self):
        output = run_stron(STRON3, INSTANCE3, self.isrc_factory)
        #print output
        #normalize text, a bit slow for large files with much non-ws
        output = normalize_text(output)
        #print output

        expected = '<?xml version="1.0" encoding="UTF-8"?>\nProcessing schema: Example Schematron Schema\nProcessing pattern: [unnamed]\nAssertion failure:\nA dog should have a nose.\nDiagnostic message:\nYour dog has no nose. How does he smell? Terrible. Give him a nose element,\nputting it after the bone element.\nDiagnostic message:\nAnimals such as dog usually come with a full complement\nof legs, ears and noses, etc. However, exceptions are possible.\nIf your dog is exceptional, provide an attribute\n<emph>exceptional=\'true\'</emph>\n'
        self.assertEqual(output, expected)
        #self.assertRaises(AttributeError, binding.xbel.folder.)
        return

    def testStron7(self):
        output = run_stron(STRON1, INSTANCE4, self.isrc_factory)
        #print output
        #normalize text, a bit slow for large files with much non-ws
        output = normalize_text(output)
        #print output

        expected = '<?xml version="1.0" encoding="UTF-8"?>\nProcessing schema: Example Schematron Schema\nProcessing pattern: [unnamed]\nAssertion failure:\nA \'dog\' element should contain two \'ear\' elements.\nReport:\nThis dog has a bone.\n'
        self.assertEqual(output, expected)
        return

    def testStron8(self):
        self.assertRaises(TypeError,
                          run_stron, STRON4, INSTANCE1, self.isrc_factory)
        return


if __name__ == '__main__':
    unittest.main()


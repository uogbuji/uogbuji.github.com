#ifndef DOMLETTE_DEBUG_H
#define DOMLETTE_DEBUG_H

#ifdef __cplusplus
extern "C" {
#endif

/* Use these defines to control different aspects of debugging */

/* Debug the append child calls */
/*#define DEBUG_NODE_APPEND_CHILD */

/* Debug the remove child calls */
/*#define DEBUG_NODE_REMOVE_CHILD */

/* Debug the replace child calls */
/*#define DEBUG_NODE_REPLACE_CHILD */

/* Debug the insert before calls */
/*#define DEBUG_NODE_INSERT_BEFORE */

/* Debug the normalize calls */
/*#define DEBUG_NODE_NORMALIZE */

/* Debug the creation and destruction of nodes */
/*#define DEBUG_NODE_CREATION */

/* Debug the parser calls */
/*#define DEBUG_PARSER*/
  
/* Debug the state table calls */
/*#define DEBUG_STATE_TABLE*/
  
/* Enable all debugging flags */
/*#define DEBUG_ALL*/

#ifdef DEBUG_ALL
#define DEBUG_NODE_APPEND_CHILD
#define DEBUG_NODE_REMOVE_CHILD
#define DEBUG_NODE_INSERT_BEFORE
#define DEBUG_NODE_NORMALIZE
#define DEBUG_NODE_CREATION
#define DEBUG_PARSER
#define DEBUG_STATE_TABLE
#endif

#ifdef __cplusplus
}
#endif

#endif /* DOMLETTE_DEBUG_H */

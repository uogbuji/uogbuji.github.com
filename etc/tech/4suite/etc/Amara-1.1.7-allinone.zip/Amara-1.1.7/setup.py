#!/usr/bin/env python
########################################################################
# $Header: /var/local/cvsroot/4Suite/setup.py,v 1.38 2005/12/08 23:41:02 mbrown Exp $
"""
The master installation specification

Copyright 2005 Fourthought, Inc. (USA).
Detailed license and copyright information: http://4suite.org/COPYRIGHT
Project home, documentation, distributions: http://4suite.org/
"""

# Create a dummy __config__ module to pass some setup-only values
# to the Ft module
import os, sys, imp

config_module = 'Ft.__config__'
module = sys.modules[config_module] = imp.new_module(config_module)
module.NAME = '4Suite'
module.VERSION = '0.0'
module.DATADIR = os.path.abspath(os.path.join('Ft', 'Data'))
# If we want localizations during setup, we need to set this to the
# directory containing that message catalog hierarchy.
module.LOCALEDIR = None


# Search out available packages
import glob
packages = glob.glob(os.path.join('packages', '*.pkg'))


# Perform requested setup action(s)
from distutils import core
from Ft.Lib.DistExt import PackageManager

kwargs = {
    # our Distribution class
    'distclass': PackageManager.PackageManager,

    # PackageManager specific
    'package_info': PackageManager.LoadPackageDefinitions(packages),
    'manifest_templates': ['include packages/distutils.pkg.sample'],
    'validate_templates': ['prune Ft/Ods',
                           'prune test/Ods',
                           'prune profile/Ods',
                          ],
    'license_file': 'COPYRIGHT',

     # Fields used in package metadata 1.0 (PEP 241 / Python 2.1+):
'name': "Amara",
      'version': '1.1.7',
      'description': "Amara XML Toolkit: a collection of Python/XML processing tools to complement 4Suite (http://4Suite.org)",
      'long_description': "A collection of Python/XML processing tools to complement 4Suite (http://4Suite.org).  The components are: Bindery--a data binding tool (fancy way of saying it's a very Pythonic XML API); Scimitar--an implementation of the ISO Schematron schema language for XML, which converts Schematron files to Python scripts; domtools--A set of tools to augment Python DOMs; saxtools--A set of tools to make SAX easier to use in Python",
      'url': 'http://uche.ogbuji.net/tech/4suite/amara/',
      'author': 'Uche Ogbuji',
      'author_email': 'uche.ogbuji@fourthought.com',
      'platforms': ['POSIX', 'Windows'],

      # Fields added in package metadata 1.1 (PEP 314 / Python 2.3+):
      #'Download-URL': '', # if given, must be specific to this release
      #'requires': 'Python (>2.3)',
      #'provides': ['amara', 'Ft', 'Ft.Lib', 'Ft.Xml'],
      #'obsoletes': [],
      #'conflicts': ['PyXML (<0.8.4)'],
      'download_url': 'ftp://ftp.4suite.org/pub/Amara/',
      'classifiers': [
          'Development Status :: 4 - Beta',
          'License :: OSI Approved :: Apache Software License',
          'License :: Other/Proprietary License',
          'Operating System :: POSIX',
          'Operating System :: Microsoft :: Windows',
          'Programming Language :: Python',
          'Topic :: Software Development :: Libraries :: Python Modules',
          'Topic :: Text Processing :: Markup :: XML',
          ],
      'keywords': ['Python', 'XML', 'XPath', '4Suite'],
    }

core.setup(**kwargs)

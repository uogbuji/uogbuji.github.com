# This is temporary (2004-12-15).  Ideally, no one would be using this
# module directly, but it is possible.  This package should be removed 
# for the 1.0 final release.
raise ImportError('FtMiniDom no longer supported; use Ft.Xml.Domlette')

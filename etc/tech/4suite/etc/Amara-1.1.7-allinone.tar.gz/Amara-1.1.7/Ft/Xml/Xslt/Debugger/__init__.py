__revision__ = "$Id: __init__.py,v 1.1 2001/09/15 21:28:41 molson Exp $"

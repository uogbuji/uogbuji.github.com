########################################################################
# $Header: /var/local/cvsroot/4Suite/Ft/Share/__init__.py,v 1.3 2004/10/13 01:53:32 mbrown Exp $
"""
Static documents needed by various parts of 4Suite

Copyright 2004 Fourthought, Inc. (USA).
Detailed license and copyright information: http://4suite.org/COPYRIGHT
Project home, documentation, distributions: http://4suite.org/
"""
